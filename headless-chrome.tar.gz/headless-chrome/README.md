ARM build of headless Chromium r504294.
Tested on Raspbian. Some additional packages should be installed, lld dump of working Chrome can be found in ldd.dump.
As work around for dependencies you can apt-get install chromium-browser and manually install libgtk-3.0 or carefully install everything missing until ldd ./chrome happy.

To use it with puppeteer you should pass executablePath to .launch function, e.g.

const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({executablePath: '/home/pi/<folder with unpacked chrome>/chrome'});
  const page = await browser.newPage();
  await page.goto('https://example.com');
  await page.screenshot({path: 'example.png'});

  await browser.close();
})();

As soon as this script dump screenshot - your puppeteer is ready.

For questions and further updates: https://github.com/GoogleChrome/puppeteer/issues/550
Author: ak239spb@gmail.com

Happy hacking!
